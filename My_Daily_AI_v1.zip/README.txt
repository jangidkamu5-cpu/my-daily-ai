MY DAILY AI - Version 1
1. Unzip this folder.
2. Open index.html in Chrome.
3. Tasks, Notes and Topics are stored locally in your browser.
4. AI Assistant is currently demo/offline mode.
5. For live OpenAI AI, use a secure server-side API route; never put an API key directly in index.html.
